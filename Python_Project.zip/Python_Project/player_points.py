import sqlite3
#connecting to record_data.db
db = sqlite3.connect("record_data.db")
cursor = db.cursor()
cursor.execute("SELECT * FROM match")
row = cursor.fetchall()

def calculate_points(row):
    points = 0.0
    score = row[1]
    try:
        StrikeRate = (float(row[1]) / float(row[2]))*100  
    except:
        StrikeRate = 0
    Fours, Sixes = float(row[3]), float(row[4])

    runs = int((score - 4 * Fours - 6 * Sixes) / 2)
    no_Wkts = 10 * float(row[8])
    try:
        economy = float(row[7]) / (float(row[5]) / 6)
    except:
        economy = 0
    fielding = float(row[9]) + float(row[10]) + float(row[11])

    
    points += (Fours + 2 * Sixes + 10 * fielding + runs + no_Wkts)
      
      
    if no_Wkts >= 5:
        points += 10  
    elif no_Wkts > 3:
        points += 5
    if StrikeRate > 100:  
        points += 4
    elif StrikeRate >=80:
        points += 2
    if score > 100:
        points += 10  
    elif score >= 50:
        points += 5  
    if economy >= 3.5 and economy <= 4.5:
        points += 4  
    elif economy >= 2 and economy < 3.5:
        points += 7  
    elif economy < 2:
        points += 10  
    return points

player_points = {}
for i in row:
    player_points[i[0]] = calculate_points(i)










