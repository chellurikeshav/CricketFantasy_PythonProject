import sqlite3


game = sqlite3.connect('record_data.db')  
gamecurs = game.cursor()


gamecurs.execute('''CREATE TABLE IF NOT EXISTS match (player TEXT NOT NULL,scored INTEGER,faced INTEGER,fours INTEGER,sixes INTEGER,bowled INTEGER,maiden INTEGER,given INTEGER,wkts INTEGER,catches INTEGER,stumping INTEGER,ro INTEGER);''')

gamecurs.execute('''CREATE TABLE IF NOT EXISTS stats (player PRIMARY KEY,matches INTEGER,runs INTEGER,hundreds INTEGER,fifties INTEGER,value INTEGER,ctg TEXT NOT NULL);''')
gamecurs.execute('''CREATE TABLE IF NOT EXISTS teams (name TEXT NOT NULL,players TEXT NOT NULL,value INTEGER);''')


sql="select * from match"
gamecurs.execute(sql)
call_all=gamecurs.fetchall()
if(call_all):
    new_entry=input("\n Do you want to add more players details ? (Y/N) : ")
else:
    print("No players data found ")
    

    new_entry=input("\n Do you want to add more players details ? (Y/N) :")

while(new_entry.upper()=='Y'):
    
    add_new=[input("Player name :")]
    add_new.append(int(input("Score:")))
    add_new.append(int(input("Faced: ")))
    add_new.append(int(input("Fours: ")))
    add_new.append(int(input("Sixes: ")))
    add_new.append(int(input("Bowled: ")))
    add_new.append(int(input("Maiden: ")))
    add_new.append(int(input("Given: ")))
    add_new.append(int(input("Wkts: ")))
    add_new.append(int(input("Catches: ")))
    add_new.append(int(input("Stumping: ")))
    add_new.append(int(input("RO: ")))
    
    
    
    gamecurs.execute("INSERT INTO match (player,scored, faced, fours,sixes,bowled,maiden,given,wkts,catches,stumping,ro) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", 
                          (add_new[0],add_new[1], add_new[2], add_new[3],add_new[4],add_new[5],add_new[6],add_new[7],add_new[8],add_new[9],add_new[10],add_new[11]))
    game.commit()

    print("Data added successfully!!!.")
    
    #Adding to stats
    print("Adding information for State table ")
    add_new.append(int(input("Total matches: ")))
    add_new.append(int(input("Total runs: ")))
    add_new.append(int(input("100s: ")))
    add_new.append(int(input("50s: ")))
    add_new.append(int(input("Value: ")))
    add_new.append(input("Category as (BAT,BWL,AR,WK): "))
    
    
    gamecurs.execute("INSERT INTO stats (player,matches,runs, hundreds, fifties,value,ctg) VALUES (?,?,?,?,?,?,?)", 
                          (add_new[0],add_new[12], add_new[13], add_new[14],add_new[15],add_new[16],add_new[17]))
    game.commit()

    print("records added successfully for stats table.")

    new_entry=input("Do you Want to add more player ? (Y/N) : ")

   
        
        

        
print("Done!")   
gamecurs.close() 

    
    
    
    
    
    

    
    

    
    
    
    
    
 
                          
        

        
     
        
        
    
    
    
        

    
    
    
    
    

    
    
         
    
    
                          
        

    
    
        
        
        
    
    
        

    

