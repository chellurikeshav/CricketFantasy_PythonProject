# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main_code.ui'
#'M O T CODE'
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!

from player_points import player_points
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox

from open_team import Ui_Dialog as Open      #importing open_team
from new_entry import Ui_Dialog as New       #importing new_entry
from evaluate import Ui_evaluate_team as Eva #importing evaluate

import sqlite3
game=sqlite3.connect('record_data.db')  # connect to database 
gamecurs=game.cursor()


class Ui_MainWindow(object):
    def __init__(self):
        self.newDialog = QtWidgets.QMainWindow()
        self.new_screen = New()
        self.new_screen.setupUi(self.newDialog)

        self.EvaluateWindow = QtWidgets.QMainWindow()
        self.eval_screen = Eva()
        self.eval_screen.setupUi(self.EvaluateWindow)

        self.openDialog = QtWidgets.QMainWindow()
        self.open_screen = Open()
        self.open_screen.setupUi(self.openDialog)
        print('Welcome to Cricket Fantasy League!!!')
        

      

    # evaluate team
    def evaluate_file(self):
        self.eval_screen.setupUi(self.EvaluateWindow)
        self.EvaluateWindow.show()
        
    # open file
    def open_file(self):
        self.open_screen.setupUi(self.openDialog)
        self.openDialog.show()
        self.open_screen.openteam_button.clicked.connect(self.openteam)

    def setupUi(self, MainWindow):
        
    
   
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(906, 800)
        MainWindow.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.central_w = QtWidgets.QWidget(MainWindow)
        self.central_w.setObjectName("central_w")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout(self.central_w)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.label_3 = QtWidgets.QLabel(self.central_w)
        font = QtGui.QFont()
        font.setFamily("Yrsa")
        font.setPointSize(20)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("background-color: qradialgradient(spread:repeat, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.502488 rgba(0, 223, 255, 188), stop:0.835821 rgba(3, 0, 255, 179));")
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        self.verticalLayout_3.addWidget(self.label_3)
        self.frame = QtWidgets.QFrame(self.central_w)
        self.frame.setStyleSheet("background-color: rgb(239, 41, 41);\n"
"font: 75 10pt \"MS Shell Dlg 2\";\n"
"")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.gridLayout = QtWidgets.QGridLayout(self.frame)
        self.gridLayout.setContentsMargins(-1, 5, -1, 24)
        self.gridLayout.setObjectName("gridLayout")
        self.label_4 = QtWidgets.QLabel(self.frame)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 1, 2, 1, 1)
        self.ARL = QtWidgets.QLabel(self.frame)
        self.ARL.setStyleSheet("color: rgb(0, 170, 255);")
        self.ARL.setObjectName("ARL")
        self.gridLayout.addWidget(self.ARL, 1, 5, 1, 1)
        self.BAT = QtWidgets.QLabel(self.frame)
        self.BAT.setStyleSheet("color: rgb(0, 170, 255);")
        self.BAT.setObjectName("BAT")
        self.gridLayout.addWidget(self.BAT, 1, 1, 1, 1)
        self.label_12 = QtWidgets.QLabel(self.frame)
        self.label_12.setObjectName("label_12")
        self.gridLayout.addWidget(self.label_12, 1, 6, 1, 1)
        self.BOWL = QtWidgets.QLabel(self.frame)
        self.BOWL.setStyleSheet("color: rgb(0, 170, 255);")
        self.BOWL.setObjectName("BOWL")
        self.gridLayout.addWidget(self.BOWL, 1, 3, 1, 1)
        self.label_10 = QtWidgets.QLabel(self.frame)
        self.label_10.setObjectName("label_10")
        self.gridLayout.addWidget(self.label_10, 1, 4, 1, 1)
        self.label = QtWidgets.QLabel(self.frame)
        font = QtGui.QFont()
        font.setFamily("MS Shell Dlg 2")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(9)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.WK = QtWidgets.QLabel(self.frame)
        self.WK.setStyleSheet("color: rgb(0, 170, 255);")
        self.WK.setObjectName("WK")
        self.gridLayout.addWidget(self.WK, 1, 7, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.verticalLayout_3.addWidget(self.frame)
        self.frame_2 = QtWidgets.QFrame(self.central_w)
        self.frame_2.setStyleSheet("font: 75 10pt \"MS Shell Dlg 2\";\n"
"border-color: rgb(255, 255, 255);\n"
"background-color: rgb(252, 233, 79);\n"
"border-radius:15px;")
        self.frame_2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Plain)
        self.frame_2.setLineWidth(0)
        self.frame_2.setObjectName("frame_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.frame_2)
        self.horizontalLayout.setContentsMargins(46, 8, 23, 5)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_6 = QtWidgets.QLabel(self.frame_2)
        self.label_6.setStyleSheet("font: 75 9pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
        self.horizontalLayout.addWidget(self.label_6)
        self.points_available = QtWidgets.QLabel(self.frame_2)
        self.points_available.setStyleSheet("color: rgb(85, 170, 255);")
        self.points_available.setObjectName("points_available")
        self.horizontalLayout.addWidget(self.points_available)
        self.label_7 = QtWidgets.QLabel(self.frame_2)
        self.label_7.setObjectName("label_7")
        self.horizontalLayout.addWidget(self.label_7, 0, QtCore.Qt.AlignRight)
        self.points_used = QtWidgets.QLabel(self.frame_2)
        self.points_used.setStyleSheet("color: rgb(85, 170, 255);")
        self.points_used.setObjectName("points_used")
        self.horizontalLayout.addWidget(self.points_used, 0, QtCore.Qt.AlignHCenter)
        self.verticalLayout_3.addWidget(self.frame_2)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        spacerItem = QtWidgets.QSpacerItem(13, 345, QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem)
        self.frame_3 = QtWidgets.QFrame(self.central_w)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_3.sizePolicy().hasHeightForWidth())
        self.frame_3.setSizePolicy(sizePolicy)
        self.frame_3.setStyleSheet("border-color: rgb(15, 15, 15);")
        self.frame_3.setFrameShape(QtWidgets.QFrame.Panel)
        self.frame_3.setFrameShadow(QtWidgets.QFrame.Plain)
        self.frame_3.setLineWidth(2)
        self.frame_3.setMidLineWidth(1)
        self.frame_3.setObjectName("frame_3")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.frame_3)
        self.verticalLayout.setContentsMargins(19, -1, 19, -1)
        self.verticalLayout.setObjectName("verticalLayout")
        self.frame_5 = QtWidgets.QFrame(self.frame_3)
        self.frame_5.setStyleSheet("color: rgb(0, 0, 0);\n"
"background-color: rgb(186, 189, 182);\n"
"border-radius:15px\n"
"")
        self.frame_5.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame_5.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.frame_5.setObjectName("frame_5")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.frame_5)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.radiobutton_bat = QtWidgets.QRadioButton(self.frame_5)
        self.radiobutton_bat.setEnabled(False)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.radiobutton_bat.sizePolicy().hasHeightForWidth())
        self.radiobutton_bat.setSizePolicy(sizePolicy)
        self.radiobutton_bat.setObjectName("radiobutton_bat")
        self.horizontalLayout_2.addWidget(self.radiobutton_bat)
        self.radiobutton_bow = QtWidgets.QRadioButton(self.frame_5)
        self.radiobutton_bow.setEnabled(False)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.radiobutton_bow.sizePolicy().hasHeightForWidth())
        self.radiobutton_bow.setSizePolicy(sizePolicy)
        self.radiobutton_bow.setObjectName("radiobutton_bow")
        self.horizontalLayout_2.addWidget(self.radiobutton_bow)
        self.radiobutton_ar = QtWidgets.QRadioButton(self.frame_5)
        self.radiobutton_ar.setEnabled(False)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.radiobutton_ar.sizePolicy().hasHeightForWidth())
        self.radiobutton_ar.setSizePolicy(sizePolicy)
        self.radiobutton_ar.setObjectName("radiobutton_ar")
        self.horizontalLayout_2.addWidget(self.radiobutton_ar)
        self.radiobutton_wk = QtWidgets.QRadioButton(self.frame_5)
        self.radiobutton_wk.setEnabled(False)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.radiobutton_wk.sizePolicy().hasHeightForWidth())
        self.radiobutton_wk.setSizePolicy(sizePolicy)
        self.radiobutton_wk.setObjectName("radiobutton_wk")
        self.horizontalLayout_2.addWidget(self.radiobutton_wk)
        self.verticalLayout.addWidget(self.frame_5)
        self.av_player = QtWidgets.QListWidget(self.frame_3)
        self.av_player.setStyleSheet("background-image: url(:/images/images/bdf03860773baaa726a60a15fe14fbd5-bicubic-lanczos3.jpg);")
        self.av_player.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.av_player.setObjectName("av_player")
        self.verticalLayout.addWidget(self.av_player)
        self.horizontalLayout_4.addWidget(self.frame_3)
        spacerItem1 = QtWidgets.QSpacerItem(13, 345, QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem1)
        self.label_9 = QtWidgets.QLabel(self.central_w)
        self.label_9.setStyleSheet("font: 20pt \"MS Shell Dlg 2\";")
        self.label_9.setLineWidth(-10)
        self.label_9.setMidLineWidth(-10)
        self.label_9.setObjectName("label_9")
        self.horizontalLayout_4.addWidget(self.label_9)
        spacerItem2 = QtWidgets.QSpacerItem(13, 345, QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem2)
        self.frame_4 = QtWidgets.QFrame(self.central_w)
        self.frame_4.setStyleSheet("border-color: rgb(120, 120, 120);")
        self.frame_4.setFrameShape(QtWidgets.QFrame.Panel)
        self.frame_4.setFrameShadow(QtWidgets.QFrame.Plain)
        self.frame_4.setLineWidth(2)
        self.frame_4.setMidLineWidth(1)
        self.frame_4.setObjectName("frame_4")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.frame_4)
        self.verticalLayout_2.setContentsMargins(18, 9, 14, -1)
        self.verticalLayout_2.setSpacing(6)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.frame_6 = QtWidgets.QFrame(self.frame_4)
        self.frame_6.setStyleSheet("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: rgb(186, 189, 182);\n"
"border-radius:15px;")
        self.frame_6.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame_6.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_6.setObjectName("frame_6")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(self.frame_6)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_8 = QtWidgets.QLabel(self.frame_6)
        self.label_8.setObjectName("label_8")
        self.horizontalLayout_3.addWidget(self.label_8, 0, QtCore.Qt.AlignHCenter)
        self.team_name = QtWidgets.QLabel(self.frame_6)
        self.team_name.setStyleSheet("color: rgb(92, 53, 102);")
        self.team_name.setObjectName("team_name")
        self.horizontalLayout_3.addWidget(self.team_name)
        self.verticalLayout_2.addWidget(self.frame_6)
        self.sel_player = QtWidgets.QListWidget(self.frame_4)
        self.sel_player.setStyleSheet("background-image: url(:/images/images/bdf03860773baaa726a60a15fe14fbd5-bicubic-lanczos3.jpg);")
        self.sel_player.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.sel_player.setObjectName("sel_player")
        self.verticalLayout_2.addWidget(self.sel_player)
        self.horizontalLayout_4.addWidget(self.frame_4)
        spacerItem3 = QtWidgets.QSpacerItem(13, 345, QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem3)
        self.verticalLayout_3.addLayout(self.horizontalLayout_4)
        MainWindow.setCentralWidget(self.central_w)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 906, 22))
        self.menubar.setObjectName("menubar")
        self.menuManage_Teams = QtWidgets.QMenu(self.menubar)
        self.menuManage_Teams.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.menuManage_Teams.setStyleSheet("selection-background-color: rgb(0, 170, 255);\n"
"\n"
"")
        self.menuManage_Teams.setObjectName("menuManage_Teams")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        
        self.new_team = QtWidgets.QAction(MainWindow)
        self.new_team.setIconText("NEW Team")
        self.new_team.setShortcut("Ctrl+N")
        self.new_team.setShortcutContext(QtCore.Qt.WindowShortcut)
        self.new_team.setVisible(True)
        self.new_team.setShortcutVisibleInContextMenu(True)
        self.new_team.setObjectName("new_team")
        
        self.open_team = QtWidgets.QAction(MainWindow)
        self.open_team.setObjectName("open_team")
        
        self.save_team = QtWidgets.QAction(MainWindow)
        self.save_team.setObjectName("save_team")
        
        self.evaluate_team = QtWidgets.QAction(MainWindow)
        self.evaluate_team.setObjectName("evaluate_team")
        
        self.actionQuit = QtWidgets.QAction(MainWindow)
        self.actionQuit.setObjectName("actionQuit") 
        self.actionQuit.triggered.connect(self.quit)
        
        self.menuManage_Teams.addAction(self.new_team)
        self.menuManage_Teams.addAction(self.open_team)
        self.menuManage_Teams.addAction(self.save_team)
        self.menuManage_Teams.addAction(self.evaluate_team)
        self.menuManage_Teams.addAction(self.actionQuit)
        self.menubar.addAction(self.menuManage_Teams.menuAction())

        
        self.new_team.triggered.connect(self.new_file)
        self.open_team.triggered.connect(self.open_file)
        self.save_team.triggered.connect(self.file_save)
        self.evaluate_team.triggered.connect(self.evaluate_file)
        self.actionQuit.triggered.connect(self.quit)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        
        self.av_player.itemDoubleClicked.connect(self.remove_available_list)
        self.sel_player.itemDoubleClicked.connect(self.remove_selected_list)

        
        self.stats = {}

        self.new_screen.save_name.clicked.connect(self.namechange)

        # Radio button settings
        self.radiobutton_bat.clicked.connect(self.load_names)
        self.radiobutton_wk.clicked.connect(self.load_names)
        self.radiobutton_bow.clicked.connect(self.load_names)
        self.radiobutton_ar.clicked.connect(self.load_names)
        
        
        
        self.initial_points = 1000
        self.used_points = 0
        self.total_player = 0
        self.total_batsmen = 0
        self.total_bowlers = 0
        self.total_allrounders = 0
        self.total_wktkprs = 0
        
        self.bowler_list = []  
        self.batsmen_list = []  
        self.allrounders_list = []   
        self.wktkprs_list = []  
        self.selected_list = []    
        

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.BAT.setText(_translate("MainWindow", "--"))
        self.label_3.setText(_translate("MainWindow", "FANTASY CRICKET LEAGUE"))
        self.label_2.setText(_translate("MainWindow", "Batsman(BAT)"))
        self.WK.setText(_translate("MainWindow", "--"))
        self.label_4.setText(_translate("MainWindow", "Bowlers(BOW)"))
        self.label_10.setText(_translate("MainWindow", "AllRounders(AR) "))
        self.ARL.setText(_translate("MainWindow", "--"))
        self.BOWL.setText(_translate("MainWindow", "--"))
        self.label_12.setText(_translate("MainWindow", "Wicket-Keeper(WK)"))
        self.label.setText(_translate("MainWindow", "Your Selection"))
        self.label_6.setText(_translate("MainWindow", "Available Points"))
        self.points_available.setText(_translate("MainWindow", "----"))
        self.label_7.setText(_translate("MainWindow", "Used Points"))
        self.points_used.setText(_translate("MainWindow", "----"))
        self.radiobutton_bat.setText(_translate("MainWindow", "BAT"))
        self.radiobutton_bow.setText(_translate("MainWindow", "BOW"))
        self.radiobutton_ar.setText(_translate("MainWindow", "AR"))
        self.radiobutton_wk.setText(_translate("MainWindow", "WK"))
        self.label_9.setText(_translate("MainWindow", ">"))
        self.label_8.setText(_translate("MainWindow", "Team Name  :"))
        self.team_name.setText(_translate("MainWindow", "Displayed Here"))
        self.menuManage_Teams.setTitle(_translate("MainWindow", "Manage Teams"))
        self.new_team.setText(_translate("MainWindow", "NEW Team"))
        self.new_team.setShortcut(_translate("MainWindow", "Ctrl+N"))
        self.open_team.setText(_translate("MainWindow", "OPEN Team"))
        self.open_team.setShortcut(_translate("MainWindow", "Ctrl+O"))
        self.save_team.setText(_translate("MainWindow", "SAVE team"))
        self.save_team.setShortcut(_translate("MainWindow", "Ctrl+S"))
        self.evaluate_team.setText(_translate("MainWindow", "EVALUATE Team"))
        self.evaluate_team.setShortcut(_translate("MainWindow", "Ctrl+E"))
        self.actionQuit.setText(_translate("MainWindow", "QUIT"))
        
    def enable_radiobuttons(self):
        self.radiobutton_bat.setEnabled(True)
        self.radiobutton_bow.setEnabled(True)
        self.radiobutton_ar.setEnabled(True)
        self.radiobutton_wk.setEnabled(True)
        
    def disable_radiobuttons(self):
        self.radiobutton_bat.setEnabled(False)
        self.radiobutton_bow.setEnabled(False)
        self.radiobutton_ar.setEnabled(False)
        self.radiobutton_wk.setEnabled(False)   
        
    #new file
    def new_file(self):
        self.newDialog.show()
    # creating new team 
    def namechange(self):
        teamname = self.new_screen.team_name.text()
        gamecurs.execute("SELECT DISTINCT name FROM teams")
        l = gamecurs.fetchall()
        for k in l:
            if k[0] == teamname:
                msg = QtWidgets.QMessageBox()
                msg.setIcon(QtWidgets.QMessageBox.Information)
                msg.setText("Team with same name already exists!!\nPlease choose another name")
                msg.setWindowTitle("Invalid Team Name")
                msg.exec_()
                return 0
        if len(teamname) == 0:
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Warning)
            msg.setText("You cannot leave the field blank!!!")
            msg.setWindowTitle("Invalid Team Name")
            msg.exec_()
            return 0
        elif teamname.isnumeric():
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Warning)
            msg.setText("Please enter a valid teamname\n(Name must contain atleast one character)!!")
            msg.setWindowTitle("Invalid Team Name")
            msg.exec_()
            return 0
        else:
            self.reset()
            self.tname = self.new_screen.team_name.text()
            self.team_name.setText(str('    '+self.tname))
            self.newDialog.close()
            
    #radio button settings
    def load_names(self):
        Batsman = 'BAT'
        WicketKeeper = 'WK'
        Allrounder = 'AR'
        Bowler = 'BWL'
        sql1 = "SELECT player,value from stats WHERE ctg = '" + Batsman + "';"
        sql2 = "SELECT Player,value from stats WHERE ctg = '" + WicketKeeper + "';"
        sql3 = "SELECT Player,value from stats WHERE ctg ='" + Allrounder + "';"
        sql4 = "SELECT Player,value from stats WHERE ctg = '" + Bowler + "';"

        gamecurs.execute(sql1)
        x = gamecurs.fetchall()
        gamecurs.execute(sql4)
        y = gamecurs.fetchall()
        gamecurs.execute(sql3)
        z = gamecurs.fetchall()
        gamecurs.execute(sql2)
        w = gamecurs.fetchall()

        batsmen = []
        bowlers = []
        allrounders = []
        wcktkeepers = []

        for k in x:
            batsmen.append(k[0])
            self.batsmen_list.append(k[0])
            self.stats[k[0]] = k[1]
        for k in y:
            bowlers.append(k[0])
            self.stats[k[0]] = k[1]
            self.bowler_list.append(k[0])
        for k in w:
            wcktkeepers.append(k[0])
            self.stats[k[0]] = k[1]
            self.wktkprs_list.append(k[0])
        for k in z:
            allrounders.append(k[0])
            self.stats[k[0]] = k[1]
            self.allrounders_list.append(k[0])
        for k in self.selected_list:
            if k in allrounders:
                allrounders.remove(k)
            elif k in batsmen:
                batsmen.remove(k)
            elif k in bowlers:
                bowlers.remove(k)
            elif k in wcktkeepers:
                wcktkeepers.remove(k)

        if self.radiobutton_bat.isChecked() == True:
            self.av_player.clear()
            for k in range(len(batsmen)):
                item = QtWidgets.QListWidgetItem(batsmen[k])
                font = QtGui.QFont()
                font.setBold(True)
                font.setWeight(75)
                item.setFont(font)
                self.av_player.addItem(item)
        elif self.radiobutton_bow.isChecked() == True:
            self.av_player.clear()
            for k in range(len(bowlers)):
                item = QtWidgets.QListWidgetItem(bowlers[k])
                font = QtGui.QFont()
                font.setBold(True)
                font.setWeight(75)
                item.setFont(font)
                self.av_player.addItem(item)
        elif self.radiobutton_ar.isChecked() == True:
            self.av_player.clear()
            for k in range(len(allrounders)):
                item = QtWidgets.QListWidgetItem(allrounders[k])
                font = QtGui.QFont()
                font.setBold(True)
                font.setWeight(75)
                item.setFont(font)
                self.av_player.addItem(item)

        elif self.radiobutton_wk.isChecked() == True:
            self.av_player.clear()
            for k in range(len(wcktkeepers)):
                item = QtWidgets.QListWidgetItem(wcktkeepers[k])
                font = QtGui.QFont()
                font.setBold(True)
                font.setWeight(75)
                item.setFont(font)
                self.av_player.addItem(item)
                
    def remove_available_list(self, item):   
        self.add_deduct_1(item.text())
        self.av_player.takeItem(self.av_player.row(item))
        self.sel_player.addItem(item.text())
        self.total_player = self.sel_player.count()
        self.selected_list.append(item.text())
        self.error()
        
    def remove_selected_list(self, item):   
        self.sel_player.takeItem(self.sel_player.row(item))
        self.av_player.addItem(item.text())
        self.selected_list.remove(item.text())
        self.total_player = self.sel_player.count()
        self.add_deduct_2(item.text())
        
    def add_deduct_1(self, cat):   
        self.initial_points -= self.stats[cat]
        self.used_points += self.stats[cat]
        if cat in self.bowler_list:
            self.total_bowlers += 1
        elif cat in self.wktkprs_list:
            self.total_wktkprs += 1
        elif cat in self.allrounders_list:
            self.total_allrounders += 1
        elif cat in self.batsmen_list:
            self.total_batsmen += 1

        self.points_available.setText(str(self.initial_points))
        self.points_used.setText(str(self.used_points))
        self.BOWL.setText(str(self.total_bowlers))
        self.BAT.setText(str(self.total_batsmen))
        self.ARL.setText(str(self.total_allrounders))
        self.WK.setText(str(self.total_wktkprs))
        
        
    def add_deduct_2(self, cat):   
        self.initial_points += self.stats[cat]
        self.used_points -= self.stats[cat]
        if cat in self.bowler_list:
            self.total_bowlers -= 1
        elif cat in self.wktkprs_list:
            self.total_wktkprs -= 1
        elif cat in self.allrounders_list:
            self.total_allrounders -= 1
        elif cat in self.batsmen_list:
            self.total_batsmen -= 1

        self.points_available.setText(str(self.initial_points))
        self.points_used.setText(str(self.used_points))
        self.BOWL.setText(str(self.total_bowlers))
        self.BAT.setText(str(self.total_batsmen))
        self.ARL.setText(str(self.total_allrounders))
        self.WK.setText(str(self.total_wktkprs))
        
    def file_save(self):
        if not self.error():  
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setInformativeText(' Inufficient Players (OR) Points. Please Check Again !!')
            msg.setWindowTitle("Fantasy Cricket League")
            msg.exec_()
        elif self.error(): 
            
            gamecurs.execute("SELECT DISTINCT name FROM teams;")
            x = gamecurs.fetchall()
            for k in x:
                if self.team_name.text() == k[0]:   
                    print('Updating already there')
                    gamecurs.execute("DELETE  FROM teams WHERE name='" + self.team_name.text() + "';")
            
            for k in range(self.sel_player.count()):
                gamecurs.execute("INSERT INTO teams (name,players,value) VALUES (?,?,?)",
                                 (self.team_name.text(), self.selected_list[k], player_points[self.selected_list[k]]))

            game.commit()
        
    def openteam(self):  #open team you want
        self.reset()
        teamname = self.open_screen.combo_open.currentText()
        self.team_name.setText(teamname)
        self.enable_radiobuttons()
        gamecurs.execute("SELECT players from teams WHERE name= '" + teamname + "';")
        x=gamecurs.fetchall()
        score=[]
        for k in x:
            gamecurs.execute("SELECT value from stats WHERE player='"+k[0]+"';")
            y=gamecurs.fetchone()
            score.append(y[0])
        sum=0
        for k in score:
            sum+=k
        self.sel_player.clear()
        self.load_names()
        for k in x:
            self.sel_player.addItem(k[0])
            self.selected_list.append(k[0])
            self.add_deduct_1(k[0])
        self.used_points = sum
        self.initial_points = 1000 - sum
        self.points_available.setText(str(self.initial_points))
        self.points_used.setText(str(self.used_points))
        self.openDialog.close()
        
        
    #reset data
    def reset(self):
        self.enable_radiobuttons()
        self.load_names()
        self.used_points = 0
        self.total_allrounders = 0
        self.total_wktkprs = 0
        self.total_batsmen = 0
        self.total_bowlers = 0
        self.total_player = 0
        self.initial_points = 1000
        self.points_available.setText(str(self.initial_points))
        self.points_used.setText(str(self.used_points))
        self.BOWL.setText(str(self.total_bowlers))
        self.BAT.setText(str(self.total_batsmen))
        self.ARL.setText(str(self.total_allrounders))
        self.WK.setText(str(self.total_wktkprs))
        self.selected_list.clear()
        self.load_names()

        self.sel_player.clear()


        
    


    #exit application
    def quit(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Critical)
        msg.setInformativeText(' Bye !!! Hope you Enjoyed the Game.')
        msg.setWindowTitle("Fantasy Cricket League")
        msg.exec_()
        
        sys.exit() 

        

    def error(self):
        msg = QMessageBox()
        if self.total_wktkprs > 1:
            msg.setIcon(QMessageBox.Critical)
            msg.setInformativeText('Only 1 wicketkeeper is allowed in the Team!')
            msg.setWindowTitle("Error")
            msg.exec_()
            return 0
        elif self.total_player > 11:
            msg.setIcon(QMessageBox.Critical)
            msg.setInformativeText('More than 11 players are not allowed!')
            msg.setWindowTitle("Selection Error")
            msg.exec_()
            return 0
        elif self.total_player < 11 :
            return 0
        elif self.total_wktkprs < 1:
            return 0
        elif self.initial_points <= -1:
            msg.setIcon(QMessageBox.Critical)
            msg.setInformativeText('Not enough points!')
            msg.setWindowTitle("Selection Cricket")
            msg.exec_()
            return 0

        return 1
import Resourse


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
